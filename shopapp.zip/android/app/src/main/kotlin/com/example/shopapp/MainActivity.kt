package com.example.shopapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
